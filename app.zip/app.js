const readline = require('readline');//readline libs
const http = require('http');//webserver lib
const fs = require('fs');// filesystem stuff
const mime = require('mime-types');
const phpexec = require('child_process');
const qs = require('querystring');

let rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
function read(path) {
    const fileContent = fs.readFileSync(path);
    const array = JSON.parse(fileContent);
    return array;
}
let port="80";
let html='Refresh the page or go to <a href="/">home page</a>';
rl.question('Enter port for webserver: ', (answer) => {
  console.log(`Selected port: ${answer}`);
port=answer;
  rl.close();
const server = http.createServer((req, res) => {
let ecode=200;
let uurl;
let mimetype= mime.lookup("./www"+req.url);
uurl = req.url;
if(mimetype == false){
	mimetype="text/html";
}
	if (uurl == "/"){ uurl="/index.html";}else{
			 uurl = req.url;
	}
let isforb;
let forb = read('./forbidden');
isforb=forb.includes(req.url);
	if(isforb == true){
		ecode=403;

console.log("Rejecting request(Forbidden URL): "+req.method+" "+req.url+"("+ecode+") by "+req.socket.localAddress+":"+req.socket.localPort);
		html="<h1> No.</h1>(if you see this as innocent person - refresh the page)";
	}else{let fsres;let phpl;
		            phpl='./php/php.exe';

			if(mimetype == "application/x-httpd-php"){
//phpexec.exec('"./php/php.exe" '+'"./www"'+uurl,html );

if (req.method == 'POST') {
	phpl=phpl+' -B "$_POST = array(';
        var body = '';
        req.on('data', function (data) {
            body += data;
            if (body.length > 1e6)
                req.connection.destroy();
        });
        req.on('end', function () {
        	var searchParams = new URLSearchParams(body);
            var post = (qs.parse(body));
            //'param1' => 'val1', 'param2' => 'val2');"
            //+'./www'+uurl;

            searchParams.forEach(function(value, key) {

phpl=phpl+"'"+key+"' => '"+value+"',";
}); phpl=phpl+"'donotusethisparamitsonlyforclosinganarray' => 'itdoesntmakesanythingelse'"+');" -F ./www'+uurl;
            console.log(phpl);
        });
    }

try{

//const child = phpexec.execFileSync('./php/php.exe', ['./www'+uurl]);
const child = phpexec.execFileSync(phpl);
ecode=200;html =(child.toString());	console.log(html);
}catch(err){
	ecode=500; html="PHP Error has occured! Full mesage is in the console.";
	console.log("PHP compilation error in file: "+"./www/"+uurl+". Full message:"+err);
}
mimetype="text/html";}else{
		try {

 fsres = fs.readFileSync("./www"+uurl);
 ecode=200;   html =fsres;

	fsres=0;
} catch (err) {
  ecode=404; html='404 not found:( <a href="/">Home page</a>'; 	fsres=0;
  console.log("Error opening "+uurl+"! "+err);
}}
  res.setHeader('Powered-by','NodeServer by MrCheat,Inc.');

  res.writeHead(ecode, { 'Content-Type': mimetype });
  

    res.end(html);  
console.log("New request: "+req.method+" "+req.url+"("+ecode+", "+mimetype+") by "+req.socket.localAddress+":"+req.socket.localPort);
}});
server.listen(port);
console.log("Done! Listening on port "+port+"");
});
// set data


